package test.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Utill.HttpUtil;
import test.DTO.memberDTO2;

public class memberInsert2Controller implements Controller {
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String title = request.getParameter("title");
		String time = request.getParameter("time");
		String seat = request.getParameter("seat");
		
		if(title.isEmpty() || time.isEmpty() || seat.isEmpty()) {
			request.setAttribute("error", "빈칸있음@@");
			HttpUtil.forward(request, response, "/memberReserve.jsp");
		}
		
		memberDTO2 member2 = new memberDTO2(title,time,seat);
		
		
		//service 객체
		memberService service = memberService.getInstance();
		service.insertMember2(member2);
		
		
		//output
		request.setAttribute("title", title);
		HttpUtil.forward(request, response, "/result/memberReserve_output.jsp");
	}

}
