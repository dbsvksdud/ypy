package test.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Utill.HttpUtil;
import test.DTO.memberDTO;

public class memberInsertController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String id = request.getParameter("id");
		String pass = request.getParameter("pass");
		String name = request.getParameter("name");
		String mail = request.getParameter("email");
		
		if(id.isEmpty() || pass.isEmpty() || name.isEmpty() || mail.isEmpty()) {
			request.setAttribute("error", "빈칸있음!!");
			HttpUtil.forward(request, response, "/memberInsert.jsp");
		}
		
		memberDTO member = new memberDTO(id, pass, name, mail);
		
		//service 객체
		memberService service = memberService.getInstance();
		service.insertMember(member);
		
		//outputUti"
		request.setAttribute("id", id);
		HttpUtil.forward(request, response, "/result/memberInsert_output.jsp");
		
	}
}
