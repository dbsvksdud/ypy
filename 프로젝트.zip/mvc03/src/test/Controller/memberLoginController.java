package test.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Utill.HttpUtil;
import test.DTO.memberDTO;

public class memberLoginController implements Controller{
		
	@Override
	public void execute(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		
		String id = request.getParameter("id");
		String pass = request.getParameter("pass");
		
		if(id.isEmpty() || pass.isEmpty()) {
			request.setAttribute("eroor", "鍮덉뭏�엳�쓬!!");
			HttpUtil.forward(request, response, "/login.jsp");
		}
		memberDTO member = new memberDTO();
		int result =0;
		
		memberService service = memberService.getInstance();
		result = service.loginMember(id, pass);
		
		if (result==1) {
			RequestDispatcher rd = request.getRequestDispatcher("result/login_output.jsp");
			rd.forward(request, response);
			
		} else {
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
		}
		
		request.setAttribute("id", id);
		HttpUtil.forward(request, response, "/result/login_output.jsp");
	}
	
}
