package test.Controller;

import java.util.ArrayList;

import test.DAO.memberDAO;
import test.DTO.memberDTO;
import test.DTO.memberDTO2;

public class memberService {
	private static memberService service = new memberService();
	public memberDAO dao = memberDAO.getInstance();
	private memberService() {}
	
	public static memberService getInstance() {
		return service;
	}
	
	public int loginMember(String Id,String password) {
		return dao.loginMember(Id,password);
	}
	
	public void insertMember2(memberDTO2 member2) {
		dao.insertMember2(member2);
	}
	
	public void insertMember(memberDTO member) {
		dao.insertMember(member);
	}
	

}


