package test.DTO;

public class memberDTO2 {
	private String title;
	private String time;
	private String seat;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getSeat() {
		return seat;
	}
	public void setSeat(String seat) {
		this.seat = seat;
	}
	public memberDTO2() {}
	public memberDTO2(String title, String time, String seat) {
		super();
		this.title=title;
		this.time=time;
		this.seat=seat;
	}
	public memberDTO2(String time,String seat) {
		super();
		this.time = time;
		this.seat = seat;
	}
}
