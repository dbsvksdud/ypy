package test.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Utill.DBConn;
import test.DTO.memberDTO;
import test.DTO.memberDTO2;

public class memberDAO {
private static memberDAO memberdao = new memberDAO();

	private memberDAO() {}
	
	public static memberDAO getInstance() {
		return memberdao;
	}
	
	public void insertMember2 (memberDTO2 n ) {
		Connection conn = null;
		PreparedStatement pstmt1= null;
		String sql = "insert into member3 values(?,?,?)";
		
		try {
			conn = DBConn.getConnection();
			pstmt1 = conn.prepareStatement(sql);
			pstmt1.setString(1,n.getTitle());
			pstmt1.setString(2,n.getTime());
			pstmt1.setString(3,n.getSeat());
			
			pstmt1.executeUpdate();
		}
		catch(Exception ex1) {
			ex1.printStackTrace();
		}
		finally {
			if(pstmt1 != null) try{pstmt1.close();}catch(SQLException sqle1){}
			if(conn != null) try{conn.close();}catch(SQLException sqle1){}
		}
	}
	
	public void insertMember(memberDTO m) {
		Connection conn = null;
		PreparedStatement pstmt= null;
		String sql = "insert into member values(?,?,?,?)";
		
		try {
			conn = DBConn.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, m.getId());
			pstmt.setString(2, m.getPass());
			pstmt.setString(3, m.getName());
			pstmt.setString(4, m.getMail());
			
			pstmt.executeUpdate();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(pstmt != null) try{pstmt.close();}catch(SQLException sqle){}
			if(conn != null) try{conn.close();}catch(SQLException sqle){}
		}
	}
	  public int loginMember(String Id, String password) {
	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	      
	      String sql = "select pass from member where Id = ?";
	      try {
	         conn = DBConn.getConnection();
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setString(1,Id);
	         rs = pstmt.executeQuery();
	         
	         if(rs.next()) {
	            if(rs.getString(1).equals(password)) return 1;
	            else return 0;
	         }
	         return -1;
	      }
	      catch(Exception ex) {
	         ex.printStackTrace();
	      }
	      finally {
	         if(pstmt != null) try{pstmt.close();}catch(SQLException sqle){}
	         if(conn != null) try{conn.close();}catch(SQLException sqle){}
	         if(rs != null) try{rs.close();}catch(SQLException sqle){}
	      }
	      return -2;
		
	  }

}
