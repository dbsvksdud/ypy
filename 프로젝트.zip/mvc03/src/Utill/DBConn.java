package Utill;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConn {
	public static Connection getConnection() throws SQLException
	{
		Connection conn = null;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/member_test?serverTimezone=UTC";
			conn = DriverManager.getConnection(url, "root", "cs1234");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return conn;
	}
}
